// this file will have all the secure info that we need to keep private , eg. passkeys etc

export const cloudinary_upload_preset = "ifnrqds4"; // this is ur upload preset, get it from cloudinary dashboard > settings > upload > upload presets > Name
