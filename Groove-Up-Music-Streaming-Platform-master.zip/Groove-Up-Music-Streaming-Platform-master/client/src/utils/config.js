// here we stored this backend url because we can directly use it now in any function and we would not have to go and change it everywhere, because if someday we deploy it we need to change this url to that

// export const backendUrl = "http://localhost:8080"; // local backend
export const backendUrl = "https://grooveup-music-backend.vercel.app"; // deployed backend

